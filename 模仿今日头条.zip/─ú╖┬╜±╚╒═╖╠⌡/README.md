

Weichat - 仿今日头条
------
> 后面会继续开发完善，并放出相关php接口代码 ～～
>
> 志同道合的朋友可以Fork，一起撸
>
> 官方文档: https://mp.weixin.qq.com/debug/wxadoc/dev/?t=1475052055457

更新说明
------
 * 1、修改首页栏目相关问题

演示
------
<img src="https://github.com/CrazyCodes/WeiXin-SmallApps-Information/blob/master/test/pic4.gif">
<img src="https://github.com/CrazyCodes/WeiXin-SmallApps-Information/blob/master/test/pic3.gif">


目录结构
------
```shell
|--- api & WebService Api                 数据接口存放目录
|--- function & Custom Function Library   自定义函数库
|--- images & Img Resources               图片资源
|--- pages & View Dir                     Controller
|--- public & Public directory            公共目录
|--- template & Public View               通用模版
|--- uploads & Dowloads Files Dir         公共下载目录
|--- utils & Public Function              通用函数
```

模板目录
------
* 1、template [模块名称][页面名称]
* 2、template 目录以模块划分,模块内的页面放在 [模块名称][页面名称] 内
* 3、通用模版放在 [模块名称] 内

开发工具
------
微信Web开发者工具 0.10.101100

下载地址
------
最新版本 0.10.101100
<a href="https://servicewechat.com/wxa-dev-logic/download_redirect?type=x64&from=mpwiki&t=1476434677599">windows 64</a> 、 
<a href="https://servicewechat.com/wxa-dev-logic/download_redirect?type=ia32&from=mpwiki&t=1476434677599">windows 32</a> 、 
<a href="https://servicewechat.com/wxa-dev-logic/download_redirect?type=darwin&from=mpwiki&t=1476434677599">mac</a>

其他
------
The world is wonderful for code , I Am CrazyCoder

